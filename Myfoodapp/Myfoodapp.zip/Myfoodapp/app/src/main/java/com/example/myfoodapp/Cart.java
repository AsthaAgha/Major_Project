package com.example.myfoodapp;

// Cart.java
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.razorpay.Checkout;
import com.razorpay.PaymentResultListener;
import org.json.JSONObject;

public class Cart extends AppCompatActivity implements PaymentResultListener {

    private RecyclerView recyclerView;
    private RecyclerCartAdapter cartAdapter;
    private static TextView totalAmountTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        Button checkoutButton = findViewById(R.id.checkoutButton);
        recyclerView = findViewById(R.id.cartRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        totalAmountTextView = findViewById(R.id.totalPrice);

        // Create an instance of RecyclerCartAdapter (initially empty)
        cartAdapter = new RecyclerCartAdapter(this);
        recyclerView.setAdapter(cartAdapter);

        Checkout.preload(Cart.this);
        updateTotalOrderAmount();
        checkoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startPayment((int)calculateTotalOrderAmount()); // You might want to pass the actual amount here
            }
        });
    }
    public static double calculateTotalOrderAmount() {
        double totalAmount = 0.0;

        for (CartItem cartItem : SharedData.cartItems) {
            totalAmount += cartItem.getItemPrice();
        }
        return totalAmount;
    }

    public static void updateTotalOrderAmount() {
        double totalAmount = calculateTotalOrderAmount();
        totalAmountTextView.setText(String.valueOf(totalAmount));
    }

    public void startPayment(int Amount){
        Checkout checkout = new Checkout();
        checkout.setKeyID("rzp_test_NGAZfmxol2X3wT");
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("name", "JAYPEE INSTITUTE OF INFORMATION TECHNOLOGY");
            jsonObject.put("description", "");
            jsonObject.put("theme.color", "#00BCD4");
            jsonObject.put("currency", "INR");
            jsonObject.put("amount", Amount * 100);

            JSONObject retryObj = new JSONObject();
            retryObj.put("enabled", true);
            retryObj.put("max_count", 4);
            jsonObject.put("retry", retryObj);
            checkout.open(Cart.this, jsonObject);

        } catch (Exception e) {
            Toast.makeText(Cart.this, "something went wrong", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onPaymentSuccess(String s) {
        totalAmountTextView.setText(String.valueOf(0.0));
        cartAdapter.clearItems(); // If you want to clear items after successful payment
    }

    @Override
    public void onPaymentError(int i, String s) {
        // Handle payment error
    }
}
