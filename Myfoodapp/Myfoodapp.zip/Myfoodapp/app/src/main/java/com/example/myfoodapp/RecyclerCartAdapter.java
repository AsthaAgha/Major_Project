package com.example.myfoodapp;
import static com.example.myfoodapp.Cart.calculateTotalOrderAmount;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class RecyclerCartAdapter extends RecyclerView.Adapter<RecyclerCartAdapter.CartViewHolder> {

    private Context mContext;

    public RecyclerCartAdapter(Context context) {
        this.mContext = context;
    }
    public void clearItems()
    {
        SharedData.cartItems.clear();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public CartViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cart_row, parent, false);
        return new CartViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CartViewHolder holder, int position) {
        CartItem currentItem = SharedData.cartItems.get(position);
        holder.itemFoodImageView.setImageResource(currentItem.getImageResource());
        holder.itemNameTextView.setText(currentItem.getItemName());
        holder.itemQuantityTextView.setText(String.valueOf(currentItem.getItemQuantity()));
        holder.itemPriceTextView.setText(String.valueOf(currentItem.getItemPrice()));
        holder.deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedData.cartItems.remove(currentItem);
                Cart.calculateTotalOrderAmount();
                notifyDataSetChanged();
                Cart.updateTotalOrderAmount();
            }
        });

    }

    @Override
    public int getItemCount() {
        return SharedData.cartItems.size();
    }

    public static class CartViewHolder extends RecyclerView.ViewHolder {
        ImageView itemFoodImageView;
        Button deleteButton;
        TextView itemQuantityTextView,itemPriceTextView,itemNameTextView;

        public CartViewHolder(@NonNull View itemView) {
            super(itemView);
            itemFoodImageView=itemView.findViewById(R.id.cimgFood);
            itemNameTextView = itemView.findViewById(R.id.cName);
            itemQuantityTextView = itemView.findViewById(R.id.cquantityTextView);
            itemPriceTextView=itemView.findViewById(R.id.cPrice);
            deleteButton=itemView.findViewById((R.id.deleteButton));
        }
    }
}
