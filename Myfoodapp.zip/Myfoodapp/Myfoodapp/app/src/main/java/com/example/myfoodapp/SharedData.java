package com.example.myfoodapp;// SharedData.java
import com.example.myfoodapp.CartItem;

import java.util.ArrayList;

public class SharedData {
    public static ArrayList<CartItem> cartItems = new ArrayList<>();
}
